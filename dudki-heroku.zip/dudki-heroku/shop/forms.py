from django import forms
from django.core.exceptions import ValidationError
from django.contrib.auth.forms import *
from django.contrib.auth.views import *
from .models import  * 

class RegisterUserForm(UserCreationForm):
    
    email = forms.EmailField(label='Email',widget=forms.EmailInput(attrs={'class':'form-input'}))
    first_name = forms.CharField(label='Имя',widget = forms.TextInput(attrs={'class':'form-input'}))
    last_name = forms.CharField(label='Фамилия',widget = forms.TextInput(attrs={'class':'form-input'}))
    password1 = forms.CharField(label='Пароль',widget = forms.PasswordInput(attrs={'class':'form-input'}))
    password2 = forms.CharField(label='Повтор пароля',widget = forms.PasswordInput(attrs={'class':'form-input'}))
    class Meta:
        model = User
        fields = {'email','first_name','last_name','password1','password2'}

class LoginUserForm(AuthenticationForm):
    email = forms.EmailField(label='Email',widget=forms.EmailInput(attrs={'class':'form-input'}))
    password = forms.CharField(label='Пароль',widget = forms.PasswordInput(attrs={'class':'form-input'}))


class Contactform(forms.Form):
    name = forms.CharField(max_length=50,widget=forms.TextInput(attrs={'placeholder': 'Имя','class':'inputs'}))
    email = forms.CharField(label='Email',widget=forms.EmailInput(attrs={'placeholder':"Email",'class':'inputs'}))
    content = forms.CharField(widget=forms.Textarea(attrs={'placeholder': 'Сообщение','class':'inputs'}))
