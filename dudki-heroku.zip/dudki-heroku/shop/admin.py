from django.contrib import admin
from .models import *
# Register your models here.
 
class BrandAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    list_display_links = ('id', 'name')
    search_fields = ('name',)
    prepopulated_fields = {"slug": ("name",)}

class MyUserAdmin(admin.ModelAdmin):
    search_fields = ('email','first_name','last_name')
    list_filter = ('email','first_name','is_active','is_staff','is_email_verified',)
    ordering = ('-start_date',)
    list_display = ('email',"first_name",'last_name','is_active','is_staff','is_email_verified')

    fieldsets = (
        (None,{'fields':('email','first_name','last_name',)}),
        ('Permissions',{'fields':('is_staff','is_active','is_superuser',)}),
    )

    add_fieldsets = (
        (None,{
            'classes':('wide',),
            'fields':('email','last_name','first_name','password1','password2','is_active','is_staff',)
        })
    )

admin.site.register(Brand, BrandAdmin)
admin.site.register(Item)
admin.site.register(Tag)
admin.site.register(MyUser,MyUserAdmin)
admin.site.register(Cart)
admin.site.register(OrderItem)
admin.site.register(Order)
