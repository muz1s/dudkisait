$(document).ready(function() {
    $('.increment-btn').click(function (e) {
        e.preventDefault();
        
        var inc_value = $(this).closest('.product_data').find('.b_quantity').val();
        var item_total = $(this).closest('.product_data').find('.t_price').text();
        var item_prc_value = $(this).closest('.product_data').find('.item_price').val();
        var total_price = $(this).closest('.product_data2').find('total-price').val();
        var total_qnty = document.getElementsByClassName('tot_qnt');
        var value = parseInt(inc_value,10);
        var value5 = parseFloat(total_price,10);
        var value2 = parseFloat(item_total,10);
        var value3 = parseInt(item_prc_value,10);
        var value4 = parseInt(total_qnty,10);

        value = isNaN(value) ? 0 : value;
        value2 = isNaN(value2) ? 0 : value2;
        value3 = isNaN(value3) ? 0 : value3;
        value4 = isNaN(value4) ? 0 : value4;
        value5 = isNaN(value5) ? 0 : value5;
        if (value < 10)
        {
            value++;
            $(this).closest('.product_data').find('.b_quantity').val(value);
            value2 = value2+value3;
            $(this).closest('.product_data').find('.t_price').text(value2);
        }
    });
    $('.decrement-btn').click(function (e) {
        e.preventDefault();
        
        var dec_value = $(this).closest('.product_data').find('.b_quantity').val();
        var item_total = $(this).closest('.product_data').find('.t_price').text();
        var item_prc_value = $(this).closest('.product_data').find('.item_price').val();
        var value = parseInt(dec_value,10);
        var value2 = parseFloat(item_total,10);
        var value3 = parseInt(item_prc_value,10);
        value = isNaN(value) ? 0 : value;
        value2 = isNaN(value2) ? 0 : value2;
        value3 = isNaN(value3) ? 0 : value3;
        if (value > 1)
        {
            value--;
            $(this).closest('.product_data').find('.b_quantity').val(value);
            value2= value2-value3;
            $(this).closest('.product_data').find('.t_price').text(value2);
        }
    });

    $('.addToCartBtn').click(function(e) {
        e.preventDefault();

        var item_id = $(this).closest('.product_data').find('.item_id').val();
        var item_qty = $(this).closest('.product_data').find('.b_quantity').val();
        var token = $('input[name=csrfmiddlewaretoken]').val();

        $.ajax({
            method:'POST',
            url:'/add-to-cart',
            data:{
                'item_id':item_id,
                'item_qty':item_qty,
                csrfmiddlewaretoken : token
            },
            success: function(response) {
                alertify.success(response.status)
            }
        });
    });
    
    $('.changeQuantity').click(function(e) {
        e.preventDefault();

        var item_id = $(this).closest('.product_data').find('.item_id').val();
        var item_qty = $(this).closest('.product_data').find('.b_quantity').val();
        var token = $('input[name=csrfmiddlewaretoken]').val();

        $.ajax({
            method:'POST',
            url:'/update-cart',
            data:{
                'item_id':item_id,
                'item_qty':item_qty,
                csrfmiddlewaretoken : token
            },
            success: function(response) {
            }
        });
    });
    $('.delete-cart-item').click(function(e) {
        e.preventDefault();

        var item_id = $(this).closest('.product_data').find('.item_id').val();
        var token = $('input[name=csrfmiddlewaretoken]').val();

        $.ajax({
            method:'POST',
            url:'/delete-cart-item',
            data:{
                'item_id':item_id,
                csrfmiddlewaretoken : token
            },
            success: function(response) {
                alertify.success(response.status)
                $('.cartdata').load(location.href + " .cartdata");
                $('.cartdata2').load(location.href + " .cartdata2");
            }
        });
    });

});