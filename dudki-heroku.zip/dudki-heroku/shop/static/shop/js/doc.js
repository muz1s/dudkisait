var filtermenu = document.querySelector('.filter-menu');

function filterMenuToggle(){
    filtermenu.classList.toggle('filter-menu-height');
}
