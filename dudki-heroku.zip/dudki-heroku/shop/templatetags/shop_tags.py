from django import template
from shop.models import *

register = template.Library()

@register.simple_tag(name='total_qnty')
def get_total_qnty(obj):
    tq = 0
    for i in obj:
        tq += i.item_qty 
    return tq

@register.simple_tag(name='total_price')
def get_total_price(obj):
    tq = 0
    for i in obj:
        tq += i.item_qty * i.item.selling_price
    return tq