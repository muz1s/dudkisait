from django.shortcuts import render,redirect
from django.utils.text import slugify
from django.views.generic import ListView,CreateView,DetailView,TemplateView,FormView
from django.contrib.auth.views import *
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import *
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.models import User
from django.urls import reverse_lazy
from django.http.response import JsonResponse
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.utils.encoding import force_bytes,force_str,DjangoUnicodeDecodeError
from .utils import generate_token,DataMixin
from django.core.mail import EmailMessage
from dudki import settings
from .models import *
from .forms import *
from django.core.mail import send_mail
import threading

# Models
brands = Brand.objects.all()
items = Item.objects.all()

# Create your views here.
class ContactForm(FormView):
    form_class = Contactform
    template_name = 'shop/contacts.html' 
    cart = ''

    # def get(self, request, *args, **kwargs):
    #     try:
    #         self.cart = Cart.objects.filter(user=request.user)
    #     except:
    #         pass
    #     return super().get(request, *args, **kwargs)
    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs)
        # context['cart'] = self.cart
        return context


    def form_valid(self,form):
        print(form.cleaned_data)
        name = form.cleaned_data["name"]
        email = form.cleaned_data["email"]
        content = form.cleaned_data["content"]
        message = render_to_string("shop/emails/email_contact_form.html", {
            "name": name,
            "email": email,
            "content": content 
            
        })
        send_mail("Обратная связь от " + name,'Обратная связь',settings.EMAIL_HOST_USER,[settings.EMAIL_HOST_USER],html_message=message)   
        return redirect('contacts')


class EmailThread(threading.Thread):

    def __init__(self, email):
        self.email = email
        threading.Thread.__init__(self)

    def run(self):
        self.email.send()

def send_activation_email(request,user):
    current_site = get_current_site(request)
    email_subject = 'Activate your account'
    email_body = render_to_string('shop/activate.html', {
        'user': user,
        'domain': current_site,
        'uid': urlsafe_base64_encode(force_bytes(user.pk)),
        'token': generate_token.make_token(user)
    })

    mail = send_mail(
        email_subject,
        email_body,
        settings.EMAIL_HOST_USER,
        [user.email],
        fail_silently= False 
    )
    # email = EmailMessage(subject=email_subject, body=email_body,
    #     from_email=settings.EMAIL_HOST_USER,
    #     to=[user.email],)
    print('message sent')
    if not settings.TESTING:
        EmailThread(mail).start()

 
class MainPage(ListView):
    template_name = 'shop/main.html'
    model = Item
    errortext = 0
    current_user = None
    

    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs)
        context['hit_products'] = Item.objects.all()
        context['last_viewed'] = Item.objects.filter(tag=2,is_published = True)
        context['promotional_products'] = Item.objects.filter(tag=3,is_published = True)
        context['title'] = 'Главная страница'
        return context
    
    
    def dispatch(self, request):

        try:
            if request.method == "POST":

                try:
                    if request.POST.get("login"):
                        email = request.POST.get("email") 
                        password = request.POST.get("password") 
                        user = authenticate(request, email=email, password=password)
                        if user is not None:        
                            login(request, user)
                        else:
                            print('eror with auth')
                    else:
                        first_name = request.POST.get("first_name")
                        email = request.POST.get("email") 
                        first_name = request.POST.get("first_name")
                        last_name = request.POST.get("last_name")
                        password1 = request.POST.get("password1") 
                        password2 = request.POST.get("password2")
                        if password1 == password2: 
                            print('check')
                            user = MyUser.objects.create_user(email, first_name,last_name,password1)
                            send_activation_email(request,user)
                            print('check2')
                        else: 
                            self.errortext = "We sent you an email to verify your account"
                except:
                    print('что-то пошло не по плану')


        except:
            self.errortext = "1" 
        
        try:
            return render(request, self.template_name, context= {"errortext": self.errortext,'hit_products':Item.objects.filter(tag=1),'last_viewed':Item.objects.filter(tag=2),'promotional_products':Item.objects.filter(tag=3),'cart':Cart.objects.filter(user=request.user)})
        except:
            return render(request, self.template_name, context= {"errortext": self.errortext,'hit_products':Item.objects.filter(tag=1),'last_viewed':Item.objects.filter(tag=2),'promotional_products':Item.objects.filter(tag=3)})

    

    
class ProfilePage(LoginRequiredMixin,ListView):
    template_name = 'shop/profile.html'
    current_user = None
    orders_history = None
    model = MyUser
    raise_exception = True

    def get(self, request, *args, **kwargs):

        self.current_user = request.user
        self.orders_history = Order.objects.filter(user=self.current_user)
        return super().get(request, *args, **kwargs)
         
    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs)
        context['user'] = self.current_user
        context['orders_history'] = self.orders_history
        return context

class DetailOrderPage(LoginRequiredMixin,ListView):
    template_name = 'shop/detail-order.html'
    model = OrderItem
    raise_exception = True

    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs) 
        context['orderitems'] = OrderItem.objects.filter(order__tracking_no = self.kwargs['order_tracking_no'])
        return context

class ShopBrand(ListView):
    model = Item
    template_name = 'shop/index.html'
    brand_slug = slugify('bmor')
    cart = ''
    # context_object_name = 'posts'

    def get_queryset(self):
        return Item.objects.filter(brand__slug=self.kwargs['brand_slug'],is_published = True)
    
    def get(self, request, *args, **kwargs):
        try:
            self.cart = Cart.objects.filter(user=request.user)
        except:
            pass
        return super().get(request, *args, **kwargs)

    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs)
        context['brands'] = brands
        context['items'] = Item.objects.filter(brand__slug=self.kwargs['brand_slug'],is_published = True)
        b = Brand.objects.get(slug=self.kwargs['brand_slug'])
        context['brand_selected'] = b.pk
        context['cart'] = self.cart
        return context


class ShopItem(DetailView):
    model = Item
    template_name = 'shop/post-item.html'
    slug_url_kwarg = 'item_slug'
    cart = ''
    # rend = render(request, self.template_name)

    def get(self, request, *args, **kwargs):
        try:
            self.cart = Cart.objects.filter(user=request.user)
        except:
            pass
        return super().get(request, *args, **kwargs)

    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs)
        context['brands'] = brands
        item = Item.objects.get(slug=self.kwargs['item_slug'])
        context['item'] = item
        context['recommendations'] = Item.objects.filter(brand=item.brand)[:4]
        context['cart'] = self.cart
        
        return context


def send_activation_email(request,user):
    current_site = get_current_site(request)
    email_subject = 'Activate your account'
    email_body = render_to_string('shop/activate.html', {
        'user': user,
        'domain': current_site,
        'uid': urlsafe_base64_encode(force_bytes(user.pk)),
        'token': generate_token.make_token(user)
    })

    mail = send_mail(
        email_subject,
        email_body,
        settings.EMAIL_HOST_USER,
        [user.email],
        fail_silently= False 
    )
    # email = EmailMessage(subject=email_subject, body=email_body,
    #     from_email=settings.EMAIL_HOST_USER,
    #     to=[user.email],)
    print('message sent')
    if not settings.TESTING:
        EmailThread(mail).start()

def activate_user(request,uid,token):

    try:
        uid=force_str(urlsafe_base64_decode(uid))

        user = MyUser.objects.get(pk=uid)

    except:
        user=None
    
    if user and generate_token.check_token(user,token):
        user.is_email_verified=True
        user.is_active=True
        user.save()

        return redirect('main')
    
    return render(request,'shop/activate-failed.html',{'user':user})


def logout_user(request):
    logout(request)
    return redirect("main")

def itemlistAjax(request):
    items = Item.objects.all().values_list('name',flat=True)
    brands = Brand.objects.all().values_list('name',flat=True)
    itemList = list(items)
    itemList += list(brands)

    return JsonResponse(itemList,safe=False)

def searchitem(request):
    if request.method=="POST":
        searchedterm = request.POST.get('itemsearch')
        if searchedterm =="":
            return redirect(request.META.get("HTTP_REFERER"))
        else:
            item = Item.objects.filter(name__contains=searchedterm).first()
            brand = Brand.objects.filter(name__contains=searchedterm).first()
            if item:
                return redirect(item.brand.slug+'/'+item.slug)

            elif brand:
                return redirect(brand.slug+'/')

            else:
                return redirect(request.META.get("HTTP_REFERER"))
            
                
            
    return redirect(request.META.get("HTTP_REFERER"))

def pageNotFound(request, exception):
    return HttpResponseNotFound('<h1>Страница не найдена</h1>')