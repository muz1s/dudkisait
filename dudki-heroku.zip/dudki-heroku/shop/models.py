from django.db import models
from django.urls import reverse
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin,BaseUserManager

# Create your models here.
class Brand(models.Model):

    name = models.CharField(max_length=100, db_index=True, verbose_name="Бренд") 
    slug = models.SlugField(max_length=255, unique=True, db_index=True, verbose_name="URL")

    def __str__(self):
        return self.name

    
    def get_absolute_url(self):
        return reverse('brands', kwargs={'brand_slug': self.slug})

    class Meta:
        verbose_name = 'Бренд'
        verbose_name_plural = "Бренды"
        ordering = ['id']

class Tag(models.Model):

    name = models.CharField(max_length=100, db_index=True, verbose_name="Тэг") 
    slug = models.SlugField(max_length=255, unique=True, db_index=True, verbose_name="URL")

    def __str__(self):
        return self.name

    
    def get_absolute_url(self):
        return reverse('tag', kwargs={'brand_slug': self.slug})

    class Meta:
        verbose_name = 'Тег'
        verbose_name_plural = "Теги"
        ordering = ['id']


class Item(models.Model):

    name = models.CharField(max_length=100, db_index=True, verbose_name="Продукт")
    brand = models.ForeignKey('Brand', on_delete=models.PROTECT, verbose_name="Бренд")
    country = models.CharField(max_length=100,verbose_name='Страна производитель',default='Китай')
    price = models.IntegerField(default = 0,verbose_name = "Старая цена")
    selling_price = models.IntegerField(default=0,verbose_name = "Настоящая цена")
    puffs = models.IntegerField(verbose_name = "Затяжки")
    nicotine_types = (
        ('Сольовий','Сольовий'),
    )
    nicotine = models.CharField(max_length=100,verbose_name = "Вид никотина",choices=nicotine_types,default = 'Сольовий')
    nicotine_percentage = models.IntegerField(verbose_name='Содержание Никотина',default=5)
    text = models.TextField(blank=True,null=True, verbose_name="Описание")
    photo = models.ImageField(upload_to="photos/%Y/%m/%d/", verbose_name="Фото")
    tag = models.ForeignKey('Tag',on_delete=models.PROTECT,blank=True,null=True, verbose_name="Тег")
    available = models.IntegerField(default = 0,verbose_name = "В наличии")
    is_published = models.BooleanField(default=True, verbose_name="Публикация")
    slug = models.SlugField(max_length=255, unique=True, db_index=True, verbose_name="URL")
 
    def __str__(self):
        return self.name
 
    
    def get_absolute_url(self):
        return reverse('items', kwargs={'item_slug': self.slug,'brand_slug':self.brand.slug})

    class Meta:
        verbose_name = 'Продукт'
        verbose_name_plural = "Продукты"
        ordering = ['name']

class CustomAccountManager(BaseUserManager):

    def create_user(self,email, first_name, last_name, password, **other_fields):

        if not email:
            raise ValueError("Вы должны указать email")

        user = self.model(email=self.normalize_email(email),first_name = first_name,last_name=last_name,**other_fields)
        user.set_password(password)
        user.save()#save(self.db)
        return user

    def create_superuser(self,email,first_name,last_name,password,**other_fields):

        other_fields.setdefault('is_staff',True)
        other_fields.setdefault('is_superuser',True)
        other_fields.setdefault('is_active',True)
        other_fields.setdefault('is_email_verified',True)

        if other_fields.get('is_staff') is not True:
            raise ValueError("Superuser must be assigned to is_staff = True")
        if other_fields.get('is_superuser') is not True:
            raise ValueError("Superuser must be assigned to is_superuser= True")

        return self.create_user(email,first_name,last_name,password,**other_fields)

class MyUser(AbstractBaseUser,PermissionsMixin):

    email = models.EmailField(_('email adress'),unique = True,blank=True,null=True,default='')
    first_name = models.CharField(max_length=30,blank=True,null=True)
    last_name = models.CharField(max_length=30,blank=True,null=True)
    start_date = models.DateTimeField(default = timezone.now)
    is_email_verified = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    # device = models.CharField(blank=True,null=True,max_length=200)


    objects = CustomAccountManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name','last_name']

    def __str__(self):
        return self.email


# class Customer(models.Model):

#     user = models.OneToOneField(MyUser,null=True,blank=True,on_delete = models.CASCADE,default='')
#     name =  models.CharField(max_length=150,blank=True,null=True)
#     email = models.CharField(max_length=200,blank=True,null=True)
#     device = models.CharField(blank=True,null=True,max_length=200)

class Cart(models.Model):
    user = models.ForeignKey(MyUser,on_delete = models.CASCADE,blank=True,null=True)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    total_price = models.FloatField(null=False,default=0)
    item_qty = models.IntegerField(null=True,blank = True)
    created_at = models.DateTimeField(auto_now_add = True)


class Order(models.Model):
    user = models.ForeignKey(MyUser,on_delete=models.CASCADE)
    fname = models.CharField(max_length=150,null=False)
    lname = models.CharField(max_length=150,null=False)
    phone = models.CharField(max_length=150,null=False)
    country = models.CharField(max_length=150,null=False)
    city = models.CharField(max_length=150,null=False)
    land = models.CharField(max_length=150,null=False)
    address = models.CharField(max_length=150,null=False)
    post = models.CharField(max_length=150,null=False)
    total_price = models.FloatField(null=False)
    payment_mode = models.CharField(max_length=150,null=True)
    payment_id = models.CharField(max_length=250,null=False)
    orderstatuses = (
        ('Pending','Pending'),
        ('Out For Shipping','Out For Shipping'),
        ('Completed','Completed'),
        ('Canceled','Canceled')
    )
    status = models.CharField(max_length=150,choices=orderstatuses,default="Pending")
    message = models.TextField(null=True)
    tracking_no = models.CharField(max_length=150,null=True)
    created_at = models.DateTimeField(auto_now_add =True)
    created_at = models.DateTimeField(auto_now = True)

    def __str__(self):
        return self.tracking_no

    def get_absolute_url(self):
        return reverse('detail-order', kwargs={'order_tracking_no': self.tracking_no})

    def get_absolute_url_manager(self):
        return reverse('order-detail', kwargs={'order_tracking_no': self.tracking_no})
    
class OrderItem(models.Model):
    order = models.ForeignKey(Order,on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    price = models.FloatField(null=False)
    quantity = models.IntegerField(null=False)

    def __str__(self):
        return self.order.tracking_no
    
