from django.shortcuts import redirect,render
from django.http.response import JsonResponse
from shop.models import Item,Cart,Order,OrderItem

import random

def index(request):
    rawcart = Cart.objects.filter(user=request.user)
    for i in rawcart:
        if i.item_qty > i.item.available:
            Cart.objects.delete(id=i.id)
    
    cartitems = Cart.objects.filter(user=request.user)
    total_price = 0
    for i in cartitems:
        total_price = total_price + i.item.price * i.item_qty


    context = {'cartitems':cartitems,"total_price":total_price}
    return render(request,"shop/checkout.html",context)

def placeorder(request):
    if request.method == "POST":
        neworder = Order()
        neworder.user = request.user
        neworder.fname = request.POST.get('fname')
        neworder.lname = request.POST.get('lname')
        neworder.phone = request.POST.get('phone')
        neworder.country = request.POST.get('country')
        neworder.land = request.POST.get('land')
        neworder.city = request.POST.get('city')
        neworder.address = request.POST.get('address')
        neworder.post = request.POST.get('post')

        neworder.payment_mode = request.POST.get('payment_mode')

        cart = Cart.objects.filter(user=request.user)
        cart_total_price = 0

        for i in cart:
            cart_total_price = cart_total_price+ i.item.price * i.item_qty

        neworder.total_price = cart_total_price

        trackno = 'dudki'+str(random.randint(1111111,9999999))
        while Order.objects.filter(tracking_no=trackno) is None:
            trackno = 'dudki'+str(random.randint(1111111,9999999))
        
        neworder.tracking_no = trackno
        neworder.save()

        neworderitems = Cart.objects.filter(user=request.user)
        for i in neworderitems:
            OrderItem.objects.create(
                order=neworder,
                item = i.item,
                price = i.item.price,
                quantity = i.item_qty
            )

            orderitem = Item.objects.filter(id=i.item_id).first()
            orderitem.available -= i.item_qty
            orderitem.save()

        Cart.objects.filter(user=request.user).delete()
        return redirect('main')
        return JsonResponse({'status':'Добавлено в корзину'})

    return redirect('main')
