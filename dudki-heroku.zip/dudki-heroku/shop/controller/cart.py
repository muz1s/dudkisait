from django.shortcuts import redirect,render
from shop.views import ShopItem
from django.http.response import JsonResponse
from shop.models import Item,Cart,MyUser
# from django.contrib import messages

def addtocart(request):
    if request.method == 'POST':

        if request.user.is_authenticated:
            item_id = int(request.POST.get('item_id'))
            item_check = Item.objects.get(pk=item_id)
            if(item_check):
                try: 
                    Cart.objects.get(user=request.user,item_id=item_id)
                    return JsonResponse({'status':'Предмет вже у кошику'})
                except:
                    item_qty = int(request.POST.get("item_qty"))

                    if item_check.available > item_qty:
                        item = Item.objects.get(id=item_id)
                        Cart.objects.create(user=request.user,item_id=item_id,item_qty=item_qty)

                        return JsonResponse({'status':'Додано'})
                    else:
                        return JsonResponse({'status':'Тільки'+str(item_check.available)+"доступно"})
            else:
                return JsonResponse({'status':'Немає такого товару'})
    return redirect('main')

def updatecart(request):
    if request.method == 'POST':
        item_id = int(request.POST.get("item_id"))
        if Cart.objects.get(item_id=item_id,user=request.user):
            item_qty = int(request.POST.get('item_qty'))
            cart = Cart.objects.get(user=request.user,item_id=item_id)
            cart.item_qty = item_qty
            # cartitems = Cart.objects.filter(user=request.user)
            # for i in cartitems:
            #     total_price =   i.item.selling_price * i.item_qty
            # cart.total_price = total_price
            cart.save()
            
            # context = {"total_price":total_price}
            # return render(request,"shop/post-item.html",context)

            
            
        
    return redirect('main')

def deletecartItem(request):
    if request.method == 'POST':
        item_id = int(request.POST.get("item_id"))
        if(Cart.objects.filter(user=request.user,item_id=item_id)):
            cartitem = Cart.objects.get(item_id=item_id,user=request.user)
            cartitem.delete()
            return JsonResponse({'status':'Видалено успішно'})
        
    return redirect('main')



    #     if request.user.is_authenticated:
    #     item_id = int(request.POST.get('item_id'))
    #     item_check = Item.objects.get(pk=item_id)
    #     if(item_check):
    #         try: 
    #             Cart.objects.get(user=request.user.pk,item_id=item_id)
    #             return JsonResponse({'status':'Предмет уже в корзине'})
    #         except:
    #             item_qty = int(request.POST.get("item_qty"))

    #             if item_check.available > item_qty:
    #                 item = Item.objects.get(id=item_id)
    #                 Cart.objects.create(user=request.user,item_id=item_id,item_qty=item_qty)

    #                 return JsonResponse({'status':'Added'})
    #             else:
    #                 return JsonResponse({'status':'Only'+str(item_check.available)+"quantity available"})
    #     else:
    #         return JsonResponse({'status':'No such item'})
    # return redirect('main')