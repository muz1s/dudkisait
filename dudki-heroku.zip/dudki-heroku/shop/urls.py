from django.urls import path, re_path
from .views import *
from shop.controller import cart,checkout
urlpatterns = [
    path('',MainPage.as_view(), name='main'),
    path('profile/',ProfilePage.as_view(),name='profile'),
    path('contacts/',ContactForm.as_view(),name='contacts'),
    path('profile/<slug:order_tracking_no>/',DetailOrderPage.as_view(),name='detail-order'),
    path('activate-user/<uid>/<token>/',activate_user,name='activate'),
    path('<slug:brand_slug>/',ShopBrand.as_view(), name='brands'),
    path('<slug:brand_slug>/<slug:item_slug>/',ShopItem.as_view(), name='items'),
    path('add-to-cart',cart.addtocart,name='addtocart'),
    path('delete-cart-item',cart.deletecartItem,name='delete-cart-item'),
    path('update-cart',cart.updatecart,name='updatecart'),
    path('checkout',checkout.index,name='checkout'),
    path('logout',logout_user,name = 'logout' ),
    path('item-list',itemlistAjax),
    path('searchitem',searchitem,name='searchitem'),
    path('placeorder',checkout.placeorder,name='placeorder'),
]
 
    #  path('login/',LoginUser.as_view(),name='login'),
    # path('registration/',RegisterUser.as_view(),name='register'),