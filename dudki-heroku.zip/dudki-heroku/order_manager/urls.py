from django.urls import path, re_path
from .views import *
# from shop.controller import cart,checkout
urlpatterns = [
    path('',MainManager.as_view(), name='main'),
    path('order-details/<slug:order_tracking_no>/',ViewOrderDetails.as_view(),name='order-detail'),
    path('delete-order',deleteOrder,name='delete-order'),
]
 