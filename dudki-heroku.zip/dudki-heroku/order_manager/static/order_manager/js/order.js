$(document).ready(function() {
    $('.delete-order').click(function(e) {
        e.preventDefault();

        var order_id = $(this).closest('.order_data').find('.order_id').val();
        var token = $('input[name=csrfmiddlewaretoken]').val();

        $.ajax({
            method:'POST',
            url:'/delete-order',
            data:{
                'order_id':order_id,
                csrfmiddlewaretoken : token
            },
            success: function(response) {
                $('.orderdata').load(location.href + " .orderdata");
            }
        });
    });

});