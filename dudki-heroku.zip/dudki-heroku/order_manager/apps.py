from django.apps import AppConfig


class OrderManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'order_manager'
