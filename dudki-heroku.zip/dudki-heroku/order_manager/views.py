from django.shortcuts import render
from shop.models import *
from django.views.generic import ListView,TemplateView
# Create your views here.

class MainManager(ListView):

    template_name = 'order_manager/main.html'
    model = Order

    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Order Manager'
        context['orders'] = Order.objects.all().order_by('created_at')
        return context

class ViewOrderDetails(ListView):
    template_name = 'order_manager/main.html'
    model = OrderItem

    def get_context_data(self,*,object_list=None,**kwargs):
        context = super().get_context_data(**kwargs) 
        context['orderitems'] = OrderItem.objects.filter(order__tracking_no = self.kwargs['order_tracking_no'])
        context['order'] = Order.objects.get(tracking_no = self.kwargs['order_tracking_no'])
        return context


def deleteOrder(request):
    if request.method == 'POST':
        order_id = int(request.POST.get("order_id"))
        if(Order.objects.filter(id=order_id)):
            order = Order.objects.get(id=order_id)
            order.delete()    
    return redirect('')